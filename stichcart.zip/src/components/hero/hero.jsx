import React from "react";

const Hero = () => {
  return (
    <div className="hero">
      <h4>Bulk</h4>
      <h3>UNIFORM</h3>
      <p>TAILORING</p>
    </div>
  );
};

export default Hero;
