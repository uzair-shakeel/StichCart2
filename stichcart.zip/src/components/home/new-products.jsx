//libs
import React, {useState, useEffect} from 'react';
import { useDispatch, useSelector } from "react-redux";
import { ScrollMenu } from "react-horizontal-scrolling-menu";
import { Link } from "react-router-dom";
//utils
import utils from '../../util/utils';

const NewProducts = () => {

    const dispatch = useDispatch();

    useEffect(() => {
    }, []);

    return (
            <>
            </>
    )
}
export default NewProducts




