import React from "react";

const login = () => {
  return <div>Login</div>;
};

export default login;
