import { func } from "prop-types";

const DeviceInfo = {

    getUniqueId: function() {
        return "e962a16cfd0f4bd0";
    },

    getApplicationName: function(){
        return "Enclothe"
    }

}

export default DeviceInfo;