import React from "react";

const services = () => {
  return <div>Our Services</div>;
};

export default services;
