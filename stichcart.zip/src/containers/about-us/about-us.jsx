import React from "react";

const aboutus = () => {
  return <div>About Uss</div>;
};

export default aboutus;
