import React from "react";

const contactus = () => {
  return <div>Contact Us</div>;
};

export default contactus;
