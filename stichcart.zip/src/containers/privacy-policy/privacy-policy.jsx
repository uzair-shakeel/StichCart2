import React from "react";

const privacypolicy = () => {
  return <div>Privary Policy</div>;
};

export default privacypolicy;
