import React from "react";

const works = () => {
  return <div>How it works</div>;
};

export default works;
